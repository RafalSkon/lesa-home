﻿# Autonomia przy operacjach Git i GitHub

Gdy użytkownik zainicjuje dowolne zadanie związane z systemem Git lub serwisem GitHub (np. dodanie nowego projektu, aktualizacja kodu, commit, push, tworzenie repozytorium, wydań Releases, wgrywanie plików APK lub innych assetów):

1. **Pełna autonomia wykonania (End-to-End):**
   - Po zainicjowaniu zadania przez użytkownika agent wykonuje wszystkie niezbędne kroki w tle bez przerywania pracy i bez zadawania pytań pośrednich o banalne decyzje techniczne.
   - Agent automatycznie przygotowuje plik `.gitignore`, inicjalizuje repozytorium (jeśli jeszcze nie istnieje), tworzy spójne commity, wypycha zmiany (`git push`) i tworzy wydania GitHub (`gh release create`).

2. **Bezpieczeństwo i sanitizacja kodu:**
   - Agent samodzielnie weryfikuje, czy w repozytorium nie ma wrażliwych danych (kluczy API, tokenów, haseł) i zastępuje je bezpiecznymi placeholderami przed wypchnięciem do zdalnego repozytorium.

3. **Podsumowanie i gotowe linki:**
   - Po zakończeniu pełnej operacji agent od razu przedstawia użytkownikowi gotowe linki (do repozytorium, strony Releases oraz bezpośrednie linki do pobrania plików/APK) i krótkie podsumowanie.
