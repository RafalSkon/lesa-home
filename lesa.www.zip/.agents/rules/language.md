# Reguły dotyczące języka

1. **Odpowiedzi i komunikacja**: Wszystkie odpowiedzi, wyjaśnienia oraz wiadomości kierowane do użytkownika muszą być pisane wyłącznie w języku polskim.
2. **Dokumentacja i plany**: Tworzone plany wdrożenia (`implementation_plan.md`), podsumowania (`walkthrough.md`), pliki markdown oraz dokumentacja projektowa muszą być tworzone wyłącznie w języku polskim.
3. **Komentarze w kodzie**: Wszelkie komentarze w kodzie źródłowym, docstringi oraz opisy muszą być pisane wyłącznie w języku polskim.
