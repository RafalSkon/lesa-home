<?php
require_once __DIR__ . '/db.php';

$action = $_GET['action'] ?? '';

// Start session to hold login info if necessary, though we will just pass JSON back to localStorage
session_start();

if ($action === 'register') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        jsonResponse(['success' => false, 'error' => 'Method not allowed'], 405);
    }

    $data = getJsonBody();
    $username = trim($data['username'] ?? '');
    $password = $data['password'] ?? '';
    $preferredRole = $data['role'] ?? 'monter'; // 'admin' or 'monter'

    if (!$username || !$password) {
        jsonResponse(['success' => false, 'error' => 'Wymagane pole email i hasło.'], 400);
    }

    // Check if user already exists
    $stmt = $db->prepare("SELECT id FROM users WHERE username = :username");
    $stmt->execute([':username' => $username]);
    if ($stmt->fetch()) {
        jsonResponse(['success' => false, 'error' => 'Użytkownik o takim adresie email już istnieje.'], 400);
    }

    $userId = uniqid('usr_');
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $status = 'pending'; // Requires approval

    $insertStmt = $db->prepare("
        INSERT INTO users (id, username, password_hash, role, status, created_at)
        VALUES (:id, :username, :password_hash, :role, :status, :created_at)
    ");

    try {
        $insertStmt->execute([
            ':id' => $userId,
            ':username' => $username,
            ':password_hash' => $hash,
            ':role' => $preferredRole,
            ':status' => $status,
            ':created_at' => time()
        ]);
        
        // Send email notification to admin
        $to = 'rafal@lesa-home.pl';
        $subject = 'Nowa rejestracja w systemie LeSa';
        $message = "Witaj,\n\nW systemie zarejestrowal sie nowy uzytkownik:\nEmail: $username\nPreferowana rola: $preferredRole\n\nZaloguj sie do panelu Administratora, przejdz do zakladki 'Użytkownicy', aby zaakceptowac konto i przypisac odpowiednia role.\n\nPozdrawiamy,\nSystem LeSa";
        $headers = "From: system@lesa-home.pl\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
        
        // Use @ to suppress errors in case the server mail configuration is missing locally
        @mail($to, $subject, $message, $headers);

        jsonResponse([
            'success' => true, 
            'message' => 'Zarejestrowano pomyślnie. Twoje konto oczekuje na akceptację administratora.'
        ]);
    } catch (PDOException $e) {
        jsonResponse(['success' => false, 'error' => 'Błąd bazy danych: ' . $e->getMessage()], 500);
    }
}

if ($action === 'login') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        jsonResponse(['success' => false, 'error' => 'Method not allowed'], 405);
    }

    $data = getJsonBody();
    $username = trim($data['username'] ?? '');
    $password = $data['password'] ?? '';

    $stmt = $db->prepare("SELECT id, username, password_hash, role, status FROM users WHERE username = :username");
    $stmt->execute([':username' => $username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password_hash'])) {
        if ($user['status'] !== 'approved') {
            jsonResponse([
                'success' => false, 
                'error' => 'Twoje konto oczekuje na akceptację administratora.'
            ], 403);
        }
        
        // Create simple session data to return
        $userData = [
            'id' => $user['id'],
            'username' => $user['username'],
            'role' => $user['role']
        ];
        
        jsonResponse(['success' => true, 'user' => $userData]);
    } else {
        jsonResponse(['success' => false, 'error' => 'Nieprawidłowy login lub hasło.'], 401);
    }
}

if ($action === 'get_users') {
    // Note: In production we should verify admin token here, but for now we rely on obscurity/local context
    $stmt = $db->query("SELECT id, username, role, status, created_at FROM users ORDER BY created_at DESC");
    $users = $stmt->fetchAll();
    jsonResponse(['success' => true, 'users' => $users]);
}

if ($action === 'update_user') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        jsonResponse(['success' => false, 'error' => 'Method not allowed'], 405);
    }

    $data = getJsonBody();
    $id = $data['id'] ?? '';
    $role = $data['role'] ?? '';
    $status = $data['status'] ?? '';

    if (!$id) {
        jsonResponse(['success' => false, 'error' => 'Brak ID użytkownika'], 400);
    }

    $updateStmt = $db->prepare("UPDATE users SET role = :role, status = :status WHERE id = :id");
    
    try {
        $updateStmt->execute([
            ':role' => $role,
            ':status' => $status,
            ':id' => $id
        ]);
        jsonResponse(['success' => true]);
    } catch (PDOException $e) {
        jsonResponse(['success' => false, 'error' => 'Błąd bazy danych: ' . $e->getMessage()], 500);
    }
}

jsonResponse(['success' => false, 'error' => 'Nieznana akcja'], 400);
