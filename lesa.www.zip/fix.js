const fs = require('fs');
const content = fs.readFileSync('js/contract-generator.js', 'utf8');

const prefixMatch = content.match(/\/\*\*\n \* LeSa - Home: Legal Contract/g);
if (prefixMatch && prefixMatch.length > 1) {
    const firstOcc = content.indexOf('/**\n * LeSa - Home');
    const secondOcc = content.indexOf('/**\n * LeSa - Home', firstOcc + 1);
    
    const correctContent = content.substring(secondOcc);
    fs.writeFileSync('js/contract-generator.js', correctContent);
    console.log('Fixed js/contract-generator.js by removing everything before the second /**');
} else {
    console.log('No duplication found.');
}
