/**
 * LeSa - Home: Admin Hub & CAD Engineering Controller
 * Authentication, Dashboard KPIs, Contracts Registry, CAD Loop Engine, CRM Leads
 */

const AdminApp = {
  activeTab: 'dashboard',
  currentTool: 'loop',
  currentColor: '#f97316',
  pipeSpacing: 15,
  cadLoops: [],
  isDrawing: false,

  init() {
    this.checkAuth();
    this.bindAuthEvents();
    this.bindNavigation();
    this.loadContractsData();
    this.loadClientsData();
    this.loadProjectsData();
    this.initCadEngine();
    this.handleUrlParams();
    this.loadUsers();

    // Bind project search
    const projSearch = document.getElementById('filter-projects-search');
    if (projSearch) {
      projSearch.addEventListener('input', (e) => {
        this.renderProjectsList(e.target.value);
      });
    }

    // Listen for cross-tab changes (e.g. from protocols)
    window.addEventListener('storage', (e) => {
      if (e.key === 'lesa_projects') {
        this.loadProjectsData();
      }
    });
  },

  /* ================= AUTHENTICATION ================= */
  checkAuth() {
    const isAuth = localStorage.getItem('lesa_admin_auth') || sessionStorage.getItem('lesa_admin_auth');
    if (isAuth !== 'true') {
      window.location.href = 'login.html';
      return;
    }
    const authScreen = document.getElementById('auth-screen');
    const adminApp = document.getElementById('admin-app');
    if (authScreen) authScreen.classList.add('hidden');
    if (adminApp) adminApp.classList.remove('hidden');
  },

  bindAuthEvents() {
    const btnLogout = document.getElementById('btn-logout');
    if (btnLogout) {
      btnLogout.addEventListener('click', () => {
        if (confirm('Czy na pewno chcesz si� wylogowa�?')) {
          localStorage.removeItem('lesa_admin_auth');
          sessionStorage.removeItem('lesa_admin_auth');
          localStorage.removeItem('lesa_user');
          this.checkAuth();
        }
      });
    }
  },

  async approveUser(id) {
    const user = this.users.find(u => u.id === id);
    if (!user) return;
    if (window.ApiService) {
      await ApiService.updateUser(id, user.role, 'approved');
      this.showToast('Konto zosta�o zatwierdzone.');
      this.loadUsers();
    }
  },

  async revokeUser(id) {
    const user = this.users.find(u => u.id === id);
    if (!user) return;
    if (window.ApiService) {
      await ApiService.updateUser(id, user.role, 'pending');
      this.showToast('Konto zosta�o zablokowane.');
      this.loadUsers();
    }
  },

  /* ================= SETTINGS ================= */
  saveCompanySettings() {
    const profile = {
      name: document.getElementById('set-company-name').value,
      nip: document.getElementById('set-company-nip').value,
      address: document.getElementById('set-company-address').value,
      bank: document.getElementById('set-company-bank').value,
      phone: document.getElementById('set-company-phone').value,
      email: document.getElementById('set-company-email').value
    };

    localStorage.setItem('lesa_contractor_profile', JSON.stringify(profile));
    this.showToast('âś… Zapisano domyĹ›lne dane firmy dla umĂłw!');
  },

  showToast(msg) {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = 'bg-slate-900 text-white text-xs font-semibold px-4 py-3 rounded-xl shadow-xl border border-slate-700 flex items-center gap-2 transform transition-all duration-300 translate-y-2 opacity-0';
    toast.innerHTML = `
      <span class="w-2 h-2 rounded-full bg-orange-500"></span>
      <span>${msg}</span>
    `;

    container.appendChild(toast);

    setTimeout(() => {
      toast.classList.remove('translate-y-2', 'opacity-0');
    }, 10);

    setTimeout(() => {
      toast.classList.add('opacity-0', 'translate-y-2');
      setTimeout(() => toast.remove(), 300);    }, 3500);
  },



  /* ================= NAVIGATION ================= */
  bindNavigation() {
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(btn => {
      btn.addEventListener('click', () => {
        const tab = btn.dataset.tab;
        if(tab) this.switchTab(tab);
      });
    });

    const toggleBtn = document.getElementById('mobile-sidebar-toggle');
    const sidebar = document.getElementById('admin-sidebar');
    if (toggleBtn && sidebar) {
      toggleBtn.addEventListener('click', () => {
        sidebar.classList.toggle('-translate-x-full');
      });
    }

    const searchInp = document.getElementById('filter-contracts-search');
    if (searchInp) {
      searchInp.addEventListener('input', (e) => {
        this.renderContractsList(e.target.value);
      });
    }

    const btnSaveSettings = document.getElementById('btn-save-settings');
    if (btnSaveSettings) {
      btnSaveSettings.addEventListener('click', () => this.saveCompanySettings());
    }
  },

  switchTab(tabId) {
    this.activeTab = tabId;
    document.querySelectorAll('.nav-item').forEach(btn => {
      if (btn.dataset.tab === tabId) {
        btn.classList.add('bg-slate-800/80', 'text-white');
        btn.classList.remove('text-slate-300');
      } else {
        btn.classList.remove('bg-slate-800/80', 'text-white');
        btn.classList.add('text-slate-300');
      }
    });

    document.querySelectorAll('.tab-pane').forEach(pane => {
      if (pane.id === `tab-${tabId}`) {
        pane.classList.remove('hidden');
      } else {
        pane.classList.add('hidden');
      }
    });
  },

  handleUrlParams() {
    const params = new URLSearchParams(window.location.search);
    if (params.has('tab')) {
      this.switchTab(params.get('tab'));
    } else {
      this.switchTab('dashboard');
    }
  },

  /* ================= USERS ================= */
  users: [],
  async loadUsers() {
    if (window.ApiService) {
      this.users = await ApiService.getUsers();
      this.renderUsersList();
    }
  },

  renderUsersList() {
    const tbody = document.getElementById('users-table-body');
    if (!tbody) return;
    tbody.innerHTML = '';
    
    if (this.users.length === 0) {
      tbody.innerHTML = `<tr><td colspan="4" class="px-6 py-4 text-center text-sm text-slate-500">Brak u�ytkownik�w.</td></tr>`;
      return;
    }

    this.users.forEach(u => {
      const isPending = u.status === 'pending';
      tbody.innerHTML += `
        <tr class="hover:bg-slate-50">
          <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900">${u.username}</td>
          <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
            <select class="border-slate-300 rounded text-xs" onchange="AdminApp.updateUserRole('${u.id}', this.value)">
              <option value="admin" ${u.role === 'admin' ? 'selected' : ''}>Admin</option>
              <option value="monter" ${u.role === 'monter' ? 'selected' : ''}>Monter</option>
            </select>
          </td>
          <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${isPending ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800'}">
              ${u.status}
            </span>
          </td>
          <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
            ${isPending ? 
              `<button onclick="AdminApp.approveUser('${u.id}')" class="text-emerald-600 hover:text-emerald-900 mr-3">Zatwierd�</button>` : 
              `<button onclick="AdminApp.revokeUser('${u.id}')" class="text-rose-600 hover:text-rose-900 mr-3">Zablokuj</button>`
            }
          </td>
        </tr>
      `;
    });
  },

  async updateUserRole(id, role) {
    const user = this.users.find(u => u.id === id);
    if (!user) return;
    if (window.ApiService) {
      await ApiService.updateUser(id, role, user.status);
      this.showToast('Zmieniono rol� u�ytkownika.');
      this.loadUsers();
    }
  },

  /* ================= CRM & DATA ================= */
  clients: [],
  projects: [],
  contracts: [],

  async loadClientsData() {
    if (window.ApiService) {
      this.clients = await ApiService.getClients() || [];
      this.updateDashboardKPIs();
    }
  },

  async loadProjectsData() {
    if (window.ApiService) {
      this.projects = await ApiService.getProjects() || [];
      this.updateDashboardKPIs();
    }
  },

  async loadContractsData() {
    if (window.ApiService) {
      this.contracts = await ApiService.getContracts() || [];
      this.renderContractsList();
      this.updateDashboardKPIs();
    }
  },

  renderContractsList(filter = '') {
    const tbody = document.getElementById('contracts-table-body');
    if (!tbody) return;
    tbody.innerHTML = '';
    
    let filtered = this.contracts;
    if (filter) {
      const term = filter.toLowerCase();
      filtered = this.contracts.filter(c => 
        (c.contract_number && c.contract_number.toLowerCase().includes(term)) || 
        (c.client_name && c.client_name.toLowerCase().includes(term))
      );
    }
    
    filtered.forEach(c => {
      tbody.innerHTML += `
        <tr>
          <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900">${c.contract_number}</td>
          <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-500">${c.client_name}</td>
          <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-500">${c.created_at}</td>
        </tr>
      `;
    });
  },

  updateDashboardKPIs() {
    const elContracts = document.getElementById('kpi-contracts-count');
    if (elContracts) elContracts.textContent = this.contracts.length;
    
    const bContracts = document.getElementById('badge-contracts-count');
    if (bContracts) bContracts.textContent = this.contracts.length;
    
    const bClients = document.getElementById('badge-clients-count');
    if (bClients) bClients.textContent = this.clients.length;
    
    const bProjects = document.getElementById('badge-projects-count');
    if (bProjects) bProjects.textContent = this.projects.length;
  },

  initCadEngine() {
    // placeholder
  }
};

document.addEventListener('DOMContentLoaded', () => {
  AdminApp.init();
});
